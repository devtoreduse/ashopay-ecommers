export const simillar_products = [
  "https://img.ltwebstatic.com/images3_pi/2021/12/01/163835112450f18e45812a67de27b54b856b289a1c_thumbnail_600x.webp",
  "https://img.ltwebstatic.com/images3_pi/2022/07/25/16587323030e63f33718ec8ee0d5b8f433d6297d3a_thumbnail_600x.webp",
  "https://img.ltwebstatic.com/images3_pi/2022/10/08/1665196724a73dce71c0ef37de4e337f2ec4e3ab66_thumbnail_600x.webp",
  "https://img.ltwebstatic.com/images3_pi/2022/08/10/16601197629680ca1281db886ba68368eb65ed640c_thumbnail_600x.webp",
  "https://img.ltwebstatic.com/images3_pi/2021/11/18/1637200963aa268a6c91513018b64fb2c9c0e8e96f_thumbnail_600x.webp",
  "https://img.ltwebstatic.com/images3_pi/2022/08/31/16619299569d661e0f3b084419847cf2539840309a_thumbnail_600x.webp",
  "https://img.ltwebstatic.com/images3_pi/2022/08/18/16607871323d1a6eb04a6600c249b2ed36cb316e56_thumbnail_600x.webp",
  "https://img.ltwebstatic.com/images3_pi/2022/07/14/165779221872fb16570962bb645143f00baf77daa9_thumbnail_600x.webp",
];
