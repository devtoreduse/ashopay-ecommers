import { addDoc, collection, doc, setDoc } from 'firebase/firestore';


export async function createDocumentWithSubcollection() {
    let testImg="https://res.cloudinary.com/dkzmosvei/image/upload/v1729866685/product%20images/pn7sqkisellfwaif15vu.jpg"
let basedProduct={
    name: "Md Ashikur",
    description: "dafdf",
    brand: "sdfad",
    slug: "Md-Ashikur",
    category:"62d69f9e60276c9915a995b8",
    subCategories:['671b9587c6cc4cfb8b336fbd'],
    refundPolicy: "30 days",
    rating: 0,
    numReviews: 0,
    shipping: 0,
    reviews: [],
    createdAt:'2024-10-25',
    updatedAt:'2024-10-25'
}
let detailsProduct={
    name: "11",
    value: "11"
}
let questions={
    question: "11",
    answer: "11",
}
let subProducts={
    sku: "asdfasdf",
    images:[testImg,testImg],
    color:{
        color: "#e09c60",
        image: "https://res.cloudinary.com/dkzmosvei/image/upload/v1729866689/product%20style%20images/i85mm0pmhm63pd2fqbgv.jpg"
    },
    discount: 0,
    sold: 0,
    sizes:[{
      _id:uuid(),
      size: "Split King",
      qty: 11,
        price: 11,
    }]
}
// let sizeProduct={
//     size: "Split King",
//             qty: 11,
//             price: 11,
//             // _id:uuid().toString()
// }



    try {
      const mainDocRef = doc(collection(db, 'products'));
      await setDoc(mainDocRef, basedProduct);

      const subDetailsRef = collection(mainDocRef, 'details');
      await addDoc(subDetailsRef, detailsProduct);

      const subQuestionsRef = collection(mainDocRef, 'questions');
      await addDoc(subQuestionsRef, questions);

      const subProductsRef = collection(mainDocRef, 'subProducts');
      await addDoc(subProductsRef, subProducts);





      console.log('Document and subcollection created successfully!');
    } catch (error) {
      console.error('Error adding document: ', error);
    }
  }