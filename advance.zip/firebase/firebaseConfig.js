import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyCIB97HaN2uCXF5TJu1Wp0zP2oeFg5iuA8",
  authDomain: "ecommersk-3fd46.firebaseapp.com",
  projectId: "ecommersk-3fd46",
  storageBucket: "ecommersk-3fd46.appspot.com",
  messagingSenderId: "102523857516",
  appId: "1:102523857516:web:b6b305981487423b1f8649",
  measurementId: "G-CW8F1SJ7S8"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);